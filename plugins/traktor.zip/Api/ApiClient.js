const API_BASE_URL = 'http://localhost:3000/data';

function send(data) {
  const request = new XMLHttpRequest();
  request.open('POST', API_BASE_URL, true);
  request.setRequestHeader('content-type', 'application/json');
  request.send(encodeURI(JSON.stringify(data)));
}
