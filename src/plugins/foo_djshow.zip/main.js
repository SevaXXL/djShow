﻿"use strict";

const url = 'http://localhost:3000/data';
let consolInfo = '';

function on_playback_new_track(newTrack) {

  const playlistId = plman.PlayingPlaylist;
  const playlistItems = plman.GetPlaylistItems(playlistId);
  const trackIndex = playlistItems.Find(newTrack);

  const tfo = {
      artist: fb.TitleFormat('%artist%'),
       title: fb.TitleFormat('%title%'),
        year: fb.TitleFormat('%year%'),
       genre: fb.TitleFormat('%genre%'),
   trackName: fb.TitleFormat('"%title%" %artist%')
  };

  const trackData = {
    artist: tfo.artist.EvalWithMetadb(newTrack),
     title: tfo.title.EvalWithMetadb(newTrack),
      year: tfo.year.EvalWithMetadb(newTrack),
     genre: tfo.genre.EvalWithMetadb(newTrack)
  };

  const next = [];
  for (let i = trackIndex + 1; i < playlistItems.Count; i++) {
    if (i > trackIndex + 10) break;
    next.push({
      'artist': tfo.artist.EvalWithMetadb(playlistItems[i]),
      'genre': tfo.genre.EvalWithMetadb(playlistItems[i])
    });
  }
  const jsonData = JSON.stringify({'current': trackData, 'next': next});

  const xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
  xmlhttp.open('POST', url, true);
  xmlhttp.setRequestHeader('Content-type', 'application/json');
  xmlhttp.onreadystatechange = () => {
    if (xmlhttp.readyState == 4) {
      if (xmlhttp.status == 200) {
        consolInfo = ': ' + tfo.trackName.EvalWithMetadb(newTrack);
        console.log(`Sended to  ${url}`, xmlhttp.responseText);
      } else {
        consolInfo = `. Server ${url.slice(0, -5)} not found!`;
      }
    }
    window.Repaint();
  };
  xmlhttp.send(jsonData);
}

// Window size
let ww = 0;
let wh = 0;

function on_size(width, height) {
  ww = width;
  wh = height;
}

function on_paint(gr) {
  const DT_VCENTER = 0x00000004;
  const DT_CENTER = 0x00000001;
  const DT_CALCRECT = 0x00000400;
  const DT_END_ELLIPSIS = 0x00008000;
  const CENTRE = DT_VCENTER | DT_CENTER | DT_CALCRECT | DT_END_ELLIPSIS;
  gr.GdiDrawText('djShow' + consolInfo, window.GetFontDUI(0), window.GetColourDUI(0), 0, 0, ww, wh, CENTRE);
}