const API_BASE_URL = 'http://localhost:3000/traktor';

function send(data) {
  const request = new XMLHttpRequest();
  request.open('POST', API_BASE_URL, true);
  request.send(JSON.stringify(data));
}